from tablettouchbase import TabletTouchBaseStateMachine

class TabletTouchSwStateMachine(TabletTouchBaseStateMachine):
    """See StateMachine base class in statemachine.py for documentation. It
    will make everything clear (or at least clearer)."""

    NAME = "TabletTouchSw"
    DESCRIPTION = "Drawing states for FluidityLab application when running a sw touch to draw test"


    def START__Touch_EvDevX(self,event):
        "A1"
        self.hdwx = event.e1
        return True

    def Touch_EvDevX__Touch_EvDevY(self,event):
        "A2"
        self.hdwy = event.e2
        return True

